<?php
/**
 * Fired During Plugin Deactivation
 *
 * @since      1.0.0
 *
 * @package    address_locator_on_ Image_map
 * @subpackage address_locator_on_ Image_map/includes
 */
 
class ALIM_deactivator {	
	  public static function deactivate() {
	
	}
}
