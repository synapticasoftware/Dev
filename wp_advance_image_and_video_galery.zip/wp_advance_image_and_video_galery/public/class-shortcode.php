<?php
/**
 * Fired For Shortcode
 *
 * @since      1.0.0
 *
 * @package    address_locator_on_ Image_map
 * @subpackage address_locator_on_ Image_map/public
 */

class ALIM_Shortcode {
    public function __construct() {
		 add_shortcode( 'alim',  array( $this, 'WAI_Show_gallery'));
	}
	public function WAI_Show_gallery( $atts ){
		wp_enqueue_script('imgmap_script', plugins_url('/assets/js/custom.js', __FILE__), array('jquery'), '', true);
    wp_enqueue_script('bootstrap', plugins_url('/lightgallery/js/bootstrap.min.js', __FILE__), array('jquery'), '', true);
    wp_enqueue_script('bootstrap-select', plugins_url('lightgallery/js/bootstrap-select.min.js', __FILE__), array('jquery'), '', true);
    wp_enqueue_script('prettify', plugins_url('/assets/js/prettify.js', __FILE__), array('jquery'), '', true);
    wp_enqueue_script('transition', plugins_url('/assets/js/transition.js', __FILE__), array('jquery'), '', true);
    wp_enqueue_script('collapse', plugins_url('/assets/js/collapse.js', __FILE__), array('jquery'), '', true);
    wp_enqueue_script('lightgallery', plugins_url('/lightgallery/js/lightgallery.js', __FILE__), array('jquery'), '', true);
    wp_enqueue_script('lg-hash', plugins_url('/lightgallery/js/lg-hash.js', __FILE__), array('jquery'), '', true);
    wp_enqueue_script('lg-video', plugins_url('/lightgallery/js/lg-video.js', __FILE__), array('jquery'), '', true);
    wp_enqueue_script('demos_script', plugins_url('/assets/js/demos.js', __FILE__), array('jquery'), '', true);

		wp_enqueue_style('bootstrap_style', plugins_url('/assets/css/bootstrap.min.css', __FILE__));
    wp_enqueue_style('bootstrap_select_style', plugins_url('/assets/css/bootstrap-select.min.css', __FILE__));
    wp_enqueue_style('lightgallery-css', plugins_url('/lightgallery/css/lightgallery.css', __FILE__));


		wp_localize_script('imgmap_script', 'ajaxurl', array('ajaxurl' => site_url().'/wp-admin/admin-ajax.php'));
  
		$args = array(
			"post_type" => ALIM_POST_TYPE,
			"posts_per_page" => -1,
      'tax_query' => array(
     array(
         'taxonomy' => 'alim_gallery',
         'field' => 'term_id',
         'terms' =>$atts['gallery']
            )
 )
		);

		$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        query_posts($args);
        if (have_posts()) :
            echo '  <div class="container-fluid">
    <div class="demo-gallery dark mrb35">
      <div class="section-header">
        <h4 class="section-title mrb15">Post Comments</h4>
      </div> <ul class="list-unstyled row commentBoxModel">';
        ?>

		<?php
		while (have_posts()) : the_post();
		global $post;
$url=get_the_post_thumbnail_url();
		?>
    <li class="col-xs-6 col-sm-4 col-md-3" data-src="static/img/1.jpg" data-sub-html='<div class="fb-comments" data-width="400" data-numposts="5"></div>'> <a href="#"> <img class="img-responsive" src="<?php echo $url; ?>">
         </a> </li>
		<?php

		endwhile;
		echo '</ul></div></div>';
		wp_reset_query();
		endif;
	}
}
$ALIM_Shortcode =new ALIM_Shortcode();
?>
