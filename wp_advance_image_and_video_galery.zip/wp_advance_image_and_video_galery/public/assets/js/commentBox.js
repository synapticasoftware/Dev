function postButtonShowhide(isvalue){
	if(isvalue){
		$('.s_postBtn').css('display','inline-block');
	}else{
		$('.s_postBtn').css('display','none');
	}
}

$('a[href^="#"]').click(function () {
	var ancherTagOrG = $.attr(this, 'href').substr(1);
	var topAncerPos = $('[id="' + $.attr(this, 'href').substr(1) + '"]').offset().top;
    $('html, body').animate({
        scrollTop: topAncerPos
    }, 800);
	
	$('#'+ancherTagOrG).focus();
    return false;
});