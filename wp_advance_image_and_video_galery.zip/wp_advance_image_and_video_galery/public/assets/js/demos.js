$(document).ready(function() {

    window.prettyPrint && prettyPrint()

    var $commentBox = $('.commentBoxModel');
    $commentBox.lightGallery({
        appendSubHtmlTo: '.lg-item',
        addClass: 'fb-comments',
        mode: 'lg-fade',
        download: true,
        enableDrag: true,
        enableSwipe: true
    });
    $commentBox.on('onAfterSlide.lg', function(event, prevIndex, index) {
		$.post("loadComments.php?id="+index, function(data){
			$('.lg-loaded .fb-comments').html(data).addClass('fb_iframe_widget');
		});
    });
});
function postButtonShowhide(isvalue){
	if(isvalue){
		$('.s_postBtn').css('display','inline-block');
	}else{
		$('.s_postBtn').css('display','none');
	}
}

$('a[href^="#"]').click(function () {
	var ancherTagOrG = $.attr(this, 'href').substr(1);
	var topAncerPos = $('[id="' + $.attr(this, 'href').substr(1) + '"]').offset().top;
    $('html, body').animate({
        scrollTop: topAncerPos
    }, 800);
	
	$('#'+ancherTagOrG).focus();
    return false;
});