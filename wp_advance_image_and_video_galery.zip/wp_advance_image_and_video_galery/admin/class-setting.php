<?php
function my_custom_column($content,$termid,$tid){
	
    $content .= '[alim gallery="'.$tid.'"]';
    return $content;
}
function add_alim_gallery_columns($columns){
    $columns['short-code'] = '<a href="#"><span>Short-Code</span><span class="sorting-indicator"></span></a>';
    return $columns;
}	
add_filter('manage_edit-alim_gallery_columns', 'add_alim_gallery_columns');
add_filter( 'manage_alim_gallery_custom_column' , 'my_custom_column' , 10 , 3 );

?>