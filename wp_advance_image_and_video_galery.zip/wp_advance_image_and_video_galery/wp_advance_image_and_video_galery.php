<?php
/*
* Plugin Name: wp advance image and video galery
* Description: This plug will help you to list video and image galery
* Author: Manish
* Author URI: test.com/
* Plugin URI: test.com/
* Version: 1.0.0
* License: GPLv2 or later
* License URI: http://www.gnu.org/licenses/gpl-2.0.html
* wp advance image and video galery is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
wp advance image and video galery is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with Address Locator on Image Map. If not, see http://www.gnu.org/licenses/gpl-2.0.html.
*/


define('WAI_LOCATOR_VERSION', '1.0.0');
define('WAI_LOCATOR_PLUGIN_URL', plugins_url('', __FILE__));
define("WAI_PATH", plugin_dir_path( __FILE__ ));
define('WAI_LOCATOR_MAP', plugin_dir_url(__FILE__) . 'admin/assets/images/map.png'); 
define('WAI_LOCATOR_SITE_URL', get_site_url());
define('WAI_LOCATOR_SLUG', 'wp_advance_image_and_video_galery');
define('ALIM_POST_TYPE', 'alim_assets'); 
//include classes and functions

require_once ( WAI_PATH . 'admin/class-cpt.php' );

require_once ( WAI_PATH . 'admin/class-setting.php' );
require_once ( WAI_PATH . 'public/class-shortcode.php' );
require_once ( WAI_PATH . 'coustom_function.php' );

require_once ( WAI_PATH . 'includes/class-alimactivator.php' );
/** This action is documented in includes/class-wb-activator.php */
register_activation_hook(__FILE__, array('ALIM_activator', 'activate')); 

/**
 * The code that runs during plugin deactivation.
 */
require_once ( WAI_PATH . 'includes/class-alimadeactivator.php' );
/** This action is documented in includes/class-wb-deactivator.php */
register_deactivation_hook(__FILE__, array('ALIM_deactivator', 'deactivate'));

?>
