=== Address Locator on Image Map ===
Contributors: theemon.com
Donate link:
Tags: Address Locator , Pin Address , Store Locater , Image Map
Requires at least: 4.0+
Tested up to: 4.5.2
Stable tag: 1.0
License: GPLv2 or later (http://www.gnu.org/licenses/gpl-2.0.html)


== DESCRIPTION ==

Address Locator on Image Map is a plugin for locating address on Image map with filter options


= Installation =

1. Download your WordPress Plugin to your desktop.
2. If downloaded as a zip archive, extract the Plugin folder to your desktop.
3. Read through the \"readme\" file thoroughly to ensure you follow the installation instructions.
4. With your FTP program, upload the Plugin folder to the wp-content/plugins folder in your WordPress directory online.
5. Go to Plugins screen and find the newly uploaded Plugin in the list.
6. Click Activate to activate it.
7. Use [map_view] Shortcode to show map 

= OTHER PREMIUM WP PLUGINS =

* WooDonation: Which is allows users to donate money to a charity organization while shopping.
  http://codecanyon.net/item/woodonation-woocommerce-donation-plugin/15044286
* Facebook events: add all the important Facebook events to your WordPress website. 
  http://codecanyon.net/item/facebook-events/15798857
* Easypay: custom and online payments hassle-free.
  http://codecanyon.net/item/easypay-wordpress-paypal-plugin-to-pay-online/9545596
* WooBooster: Array of features including product comparison, shipping availability and product filtering 
  on the basis of price,relevance and other attributes that change with the product category.
  http://codecanyon.net/item/woobooster-compare-live-search-advanced-filtering-store-locator-delivery-availability/15685442

== Changelog ==

= 1.0.0 =
* Initial Version



